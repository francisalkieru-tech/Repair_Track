import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../utils/colors.dart';
import '../../utils/constants.dart';
import '../../utils/ui_widgets.dart';

class ServiceHistoryScreen extends StatelessWidget {
  final String trackingId;

  const ServiceHistoryScreen({super.key, required this.trackingId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7F9),
      appBar: AppBar(
        title: const Text('Service History'),
        backgroundColor: AppColors.dark,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('repairRequests')
            .where('trackingId', isEqualTo: trackingId)
            .limit(1)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const AppLoadingIndicator(
                message: 'Loading service record...');
          }

          if (snapshot.hasError) {
            return AppErrorState(
                message: friendlyErrorMessage(snapshot.error));
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return _buildNotFound();
          }

          final data =
              snapshot.data!.docs.first.data() as Map<String, dynamic>;
          return _buildContent(data);
        },
      ),
    );
  }

  Widget _buildNotFound() {
    return AppEmptyState(
      icon: Icons.search_off,
      title: 'Service Record Not Found',
      subtitle: 'No service record found for tracking ID: $trackingId',
    );
  }

  Widget _buildContent(Map<String, dynamic> data) {
    final statusHistory =
        (data['statusHistory'] as List<dynamic>? ?? [])
            .cast<Map<String, dynamic>>();
    final completedEntry = statusHistory.lastWhere(
      (e) => e['status'] == 'Completed',
      orElse: () => <String, dynamic>{},
    );
    final completedAt = completedEntry['timestamp'] as Timestamp?;
    final createdAt = data['createdAt'] as Timestamp?;

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 680),
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF166534), Color(0xFF16A34A)],
              ),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.verified, color: Colors.white70, size: 16),
                    SizedBox(width: 6),
                    Text('Service Completed',
                        style:
                            TextStyle(color: Colors.white70, fontSize: AppColors.fontCaption)),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  trackingId,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 3,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  data['applianceType'] ?? '',
                  style: const TextStyle(
                      color: Colors.white, fontSize: AppColors.fontBody),
                ),
                if (completedAt != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    'Completed: ${_formatDate(completedAt.toDate())}',
                    style: const TextStyle(
                        color: Colors.white70, fontSize: AppColors.fontCaption),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Customer & Repair Info
          _buildSection(
            title: 'Customer & Repair Info',
            icon: Icons.person_outline,
            child: Column(
              children: [
                _buildRow('Customer', data['name'] ?? ''),
                _buildRow('Contact', data['contactNumber'] ?? ''),
                _buildRow('Address', data['address'] ?? ''),
                _buildRow('Appliance', data['applianceType'] ?? ''),
                _buildRow('Problem', data['problemDescription'] ?? ''),
                if (createdAt != null)
                  _buildRow(
                      'Date Filed', _formatDate(createdAt.toDate())),
                if (completedAt != null)
                  _buildRow('Date Completed',
                      _formatDate(completedAt.toDate())),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Warranty Information 
          if (data['warrantyMonths'] != null) ...[
            _buildWarrantySection(data),
            const SizedBox(height: 16),
          ],

          // Customer submitted photo
          if (data['initialPhotoUrl'] != null &&
              (data['initialPhotoUrl'] as String).isNotEmpty) ...[
            _buildSection(
              title: 'Before Photo (Customer Submitted)',
              icon: Icons.photo_camera_outlined,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.network(
                  data['initialPhotoUrl'],
                  width: double.infinity,
                  height: 180,
                  fit: BoxFit.cover,
                  loadingBuilder: (context, child, progress) {
                    if (progress == null) return child;
                    return Container(
                      height: 180,
                      alignment: Alignment.center,
                      child: const CircularProgressIndicator(
                          strokeWidth: 2, color: AppColors.dark),
                    );
                  },
                  errorBuilder: (context, error, stackTrace) => Container(
                    height: 80,
                    alignment: Alignment.center,
                    color: const Color(0xFFF3F4F6),
                    child: const Text('Failed to load photo',
                        style: TextStyle(
                            fontSize: AppColors.fontCaption, color: AppColors.textGray)),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],

          // Assigned Technician
          if (data['assignedTechnician'] != null &&
              (data['assignedTechnician'] as String).isNotEmpty) ...[
            _buildSection(
              title: 'Assigned Technician',
              icon: Icons.engineering_outlined,
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 18,
                    backgroundColor: AppColors.dark,
                    child: Icon(Icons.person,
                        color: Colors.white, size: 18),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    data['assignedTechnician'],
                    style: const TextStyle(
                        fontSize: AppColors.fontBody, fontWeight: FontWeight.w600, color: AppColors.textDark),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],

          () {
            final partsEntry = statusHistory.lastWhere(
              (e) =>
                  e['partsSource'] != null &&
                  (e['partsSource'] as String).isNotEmpty,
              orElse: () => <String, dynamic>{},
            );
            if (partsEntry.isEmpty) return const SizedBox.shrink();
            return Column(
              children: [
                _buildSection(
                  title: 'Parts Information',
                  icon: Icons.build_outlined,
                  child: _buildRow(
                      'Source', partsEntry['partsSource'] ?? ''),
                ),
                const SizedBox(height: 16),
              ],
            );
          }(),

          // Full Service History (all status entries with timestamps)
          _buildSection(
            title: 'Service History Log',
            icon: Icons.history,
            child: statusHistory.isEmpty
                ? const Text(
                    'No history entries yet.',
                    style:
                        TextStyle(fontSize: AppColors.fontLabel, color: AppColors.textGray),
                  )
                : Column(
                    children: statusHistory.asMap().entries.map((entry) {
                      final i = entry.key;
                      final item = entry.value;
                      final ts = item['timestamp'] as Timestamp?;
                      final note = item['note'] as String? ?? '';
                      final statusLabel = item['status'] as String? ?? '';
                      final tech = item['technician'] as String?;
                      final photoUrl = item['photoUrl'] as String?;
                      final hasPhoto =
                          photoUrl != null && photoUrl.isNotEmpty;
                      final isLast = i == statusHistory.length - 1;

                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Timeline dot + line
                          Column(
                            children: [
                              Container(
                                width: 28,
                                height: 28,
                                decoration: BoxDecoration(
                                  color: statusLabel == 'Completed'
                                      ? const Color(0xFF166534)
                                      : AppColors.dark,
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(Icons.check,
                                    color: Colors.white, size: 14),
                              ),
                              if (!isLast)
                                Container(
                                  width: 2,
                                  height: 60 + (hasPhoto ? 180 : 0),
                                  color: const Color(0xFFE5E7EB),
                                ),
                            ],
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Padding(
                              padding: EdgeInsets.only(
                                  top: 4, bottom: isLast ? 0 : 16),
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    AppConstants.displayLabel(statusLabel),
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: AppColors.fontLabel,
                                      color: AppColors.textDark,
                                    ),
                                  ),
                                  if (ts != null)
                                    Text(
                                      _formatDate(ts.toDate()),
                                      style: const TextStyle(
                                          fontSize: AppColors.fontCaption,
                                          color: AppColors.textLightGray),
                                    ),
                                  if (tech != null &&
                                      tech.isNotEmpty) ...[
                                    const SizedBox(height: 4),
                                    Text(
                                      'Tech: $tech',
                                      style: const TextStyle(
                                          fontSize: AppColors.fontCaption,
                                          color: AppColors.textGray),
                                    ),
                                  ],
                                  if (note.isNotEmpty) ...[
                                    const SizedBox(height: 4),
                                    Text(
                                      note,
                                      style: const TextStyle(
                                          fontSize: AppColors.fontLabel,
                                          color: Color(0xFF374151)),
                                    ),
                                  ],
                                  if (hasPhoto) ...[
                                    const SizedBox(height: 8),
                                    ClipRRect(
                                      borderRadius:
                                          BorderRadius.circular(8),
                                      child: Image.network(
                                        photoUrl,
                                        width: double.infinity,
                                        height: 160,
                                        fit: BoxFit.cover,
                                        loadingBuilder:
                                            (context, child, progress) {
                                          if (progress == null)
                                            return child;
                                          return Container(
                                            height: 160,
                                            alignment: Alignment.center,
                                            child:
                                                const CircularProgressIndicator(
                                                    strokeWidth: 2, color: AppColors.dark),
                                          );
                                        },
                                        errorBuilder:
                                            (context, error, stackTrace) => Container(
                                          height: 60,
                                          alignment: Alignment.center,
                                          color: const Color(0xFFF3F4F6),
                                          child: const Text(
                                              'Failed to load photo',
                                              style: TextStyle(
                                                  fontSize: AppColors.fontCaption,
                                                  color:
                                                      AppColors.textGray)),
                                        ),
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
          ),
          const SizedBox(height: 32),

          // Footer watermark
          Center(
            child: Column(
              children: [
                const Icon(Icons.verified_outlined,
                    color: AppColors.textLightGray, size: 20),
                const SizedBox(height: 4),
                const Text(
                  'This is an official service record from RepairTrack.',
                  style:
                      TextStyle(fontSize: AppColors.fontCaption, color: AppColors.textLightGray),
                  textAlign: TextAlign.center,
                ),
                Text(
                  'Tracking ID: $trackingId',
                  style: const TextStyle(
                      fontSize: AppColors.fontCaption,
                      color: AppColors.textLightGray),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
        ),
      ),
    );
  }

  Widget _buildWarrantySection(Map<String, dynamic> data) {
    final months = data['warrantyMonths'] as int?;
    final terms = data['warrantyTerms'] as String? ?? '';
    final expiresAt = data['warrantyExpiresAt'] as Timestamp?;

    final now = DateTime.now();
    final isActive = expiresAt != null && expiresAt.toDate().isAfter(now);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE5E7EB)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x07000000),
            blurRadius: 12,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.shield_outlined,
                  size: 18, color: AppColors.dark),
              const SizedBox(width: 8),
              const Text(
                'Warranty Information',
                style: TextStyle(
                  fontSize: AppColors.fontBody,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textDark,
                ),
              ),
              const Spacer(),
              if (expiresAt != null)
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: isActive
                        ? const Color(0xFFDCFCE7)
                        : const Color(0xFFF3F4F6),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    isActive ? 'Active' : 'Expired',
                    style: TextStyle(
                      fontSize: AppColors.fontCaption,
                      fontWeight: FontWeight.w600,
                      color: isActive
                          ? const Color(0xFF166534)
                          : AppColors.textGray,
                    ),
                  ),
                ),
            ],
          ),
          const Divider(height: 24, color: Color(0xFFE5E7EB)),
          _buildRow('Coverage',
              months != null ? '$months ${months == 1 ? 'month' : 'months'}' : ''),
          if (expiresAt != null)
            _buildRow('Valid Until', _formatDate(expiresAt.toDate())),
          if (terms.isNotEmpty) ...[
            const SizedBox(height: 4),
            const Text(
              'Terms',
              style: TextStyle(
                  fontSize: AppColors.fontLabel,
                  color: AppColors.textGray,
                  fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 4),
            Text(
              terms,
              style: const TextStyle(
                  fontSize: AppColors.fontLabel, color: AppColors.textDark),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSection({
    required String title,
    required IconData icon,
    required Widget child,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE5E7EB)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x07000000),
            blurRadius: 12,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: AppColors.dark),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: AppColors.fontBody,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textDark,
                  ),
                ),
              ),
            ],
          ),
          const Divider(height: 24, color: Color(0xFFE5E7EB)),
          child,
        ],
      ),
    );
  }

  Widget _buildRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(
              label,
              style: const TextStyle(
                  fontSize: AppColors.fontLabel, color: AppColors.textGray),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                  fontSize: AppColors.fontLabel,
                  fontWeight: FontWeight.w500,
                  color: AppColors.textDark),
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime dt) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];
    final hour = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
    final minute = dt.minute.toString().padLeft(2, '0');
    final period = dt.hour >= 12 ? 'PM' : 'AM';
    return '${months[dt.month - 1]} ${dt.day}, ${dt.year} $hour:$minute $period';
  }
}