import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show Clipboard, ClipboardData;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../../services/sms_service.dart';
import '../../services/storage_service.dart';
import '../auth/Welcome_screen.dart';
import 'admin_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _settingsStorageService = StorageService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kAdminBg,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _ShopInfoSection(storageService: _settingsStorageService),
            const SizedBox(height: 20),
            const _AccountSettingsSection(),
            const SizedBox(height: 20),
            const _NotificationSettingsSection(),
            const SizedBox(height: 20),
            const _DataSecuritySection(),
            const SizedBox(height: 20),
            const _AppInfoSettingsSection(),
          ],
        ),
      ),
    );
  }
}

// ── Shared section shell ─────────────────────────────────────────
class _SettingsPageCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget child;

  const _SettingsPageCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kAdminCardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: kAdminBrand.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: kAdminBrand, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: kAdminTextDark,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: const TextStyle(fontSize: 12, color: kAdminTextGray),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          child,
        ],
      ),
    );
  }
}

/// Reusable "label + value + edit pencil icon" row — replaces the
/// old large Save/Change buttons. When the pencil is tapped, it
/// calls the onEdit callback (usually opens a dialog).
class _SettingsInfoRow extends StatelessWidget {
  final String label;
  final String value;
  final VoidCallback onEdit;
  final bool isPlaceholder;

  const _SettingsInfoRow({
    required this.label,
    required this.value,
    required this.onEdit,
    this.isPlaceholder = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: kAdminTextGray,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: isPlaceholder ? kAdminTextGray : kAdminTextDark,
                    fontStyle:
                        isPlaceholder ? FontStyle.italic : FontStyle.normal,
                  ),
                ),
              ],
            ),
          ),
          InkWell(
            onTap: onEdit,
            borderRadius: BorderRadius.circular(20),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: kAdminBrand.withValues(alpha: 0.08),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.edit_outlined, size: 16, color: kAdminBrand),
            ),
          ),
        ],
      ),
    );
  }
}

/// Simple dialog helper — a single text field, Cancel/Save. Reused
/// throughout for all the "edit icon → dialog" patterns across the
/// Settings page.
Future<String?> _showEditFieldDialog(
  BuildContext context, {
  required String title,
  required String initialValue,
  String? hint,
  int maxLines = 1,
  TextInputType? keyboardType,
}) {
  final controller = TextEditingController(text: initialValue);
  return showDialog<String>(
    context: context,
    builder: (context) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      title: Text(title),
      content: TextField(
        controller: controller,
        autofocus: true,
        maxLines: maxLines,
        keyboardType: keyboardType,
        decoration: _settingsFieldDecoration(hint: hint),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () => Navigator.pop(context, controller.text.trim()),
          style: ElevatedButton.styleFrom(
              backgroundColor: kAdminBrand, foregroundColor: Colors.white),
          child: const Text('Save'),
        ),
      ],
    ),
  );
}

InputDecoration _settingsFieldDecoration({String? hint}) => InputDecoration(
      hintText: hint,
      isDense: true,
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: kAdminCardBorder),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: kAdminCardBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: kAdminBrand, width: 1.5),
      ),
    );

// ══════════════════════════════════════════════════════════════════
// 1. Shop/Business Info — auto-populated, just an edit icon per field
// ══════════════════════════════════════════════════════════════════

class _ShopInfoSection extends StatefulWidget {
  final StorageService storageService;
  const _ShopInfoSection({required this.storageService});

  @override
  State<_ShopInfoSection> createState() => _ShopInfoSectionState();
}

class _ShopInfoSectionState extends State<_ShopInfoSection> {
  String _shopName = '';
  String _address = '';
  String _contactNumber = '';
  String _businessHours = '';
  String? _logoUrl;
  bool _isLoading = true;
  bool _isUploadingLogo = false;
  String? _loadError;

  DocumentReference get _docRef =>
      FirebaseFirestore.instance.collection('shopSettings').doc('config');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _loadError = null;
    });
    try {
      final doc = await _docRef.get();
      if (!mounted) return;
      if (doc.exists) {
        final data = doc.data() as Map<String, dynamic>;
        setState(() {
          _shopName = data['shopName'] ?? '';
          _address = data['address'] ?? '';
          _contactNumber = data['contactNumber'] ?? '';
          _businessHours = data['businessHours'] ?? '';
          _logoUrl = data['logoUrl'] as String?;
          _isLoading = false;
        });
      } else {
        setState(() => _isLoading = false);
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _loadError = 'Unable to load shop info: $e';
      });
    }
  }

  Future<void> _saveField(String field, String value) async {
    try {
      await _docRef.set({
        field: value,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Na-save.'),
              backgroundColor: Color(0xFF16A34A)),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  Future<void> _editShopName() async {
    final result = await _showEditFieldDialog(
      context,
      title: 'Shop Name',
      initialValue: _shopName,
      hint: 'e.g. RepairTrack Shop',
    );
    if (result != null && result != _shopName) {
      setState(() => _shopName = result);
      await _saveField('shopName', result);
    }
  }

  Future<void> _editAddress() async {
    final result = await _showEditFieldDialog(
      context,
      title: 'Address',
      initialValue: _address,
      hint: 'e.g. Calatagan, Virac, Catanduanes',
      maxLines: 2,
    );
    if (result != null && result != _address) {
      setState(() => _address = result);
      await _saveField('address', result);
    }
  }

  Future<void> _editContactNumber() async {
    final result = await _showEditFieldDialog(
      context,
      title: 'Contact Number',
      initialValue: _contactNumber,
      hint: 'e.g. 09171234567',
      keyboardType: TextInputType.phone,
    );
    if (result != null && result != _contactNumber) {
      setState(() => _contactNumber = result);
      await _saveField('contactNumber', result);
    }
  }

  Future<void> _editBusinessHours() async {
    final result = await _showEditFieldDialog(
      context,
      title: 'Business Hours',
      initialValue: _businessHours,
      hint: 'e.g. Mon–Sat, 8:00 AM – 5:00 PM',
    );
    if (result != null && result != _businessHours) {
      setState(() => _businessHours = result);
      await _saveField('businessHours', result);
    }
  }

  Future<void> _pickAndUploadLogo() async {
    final picked = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 800,
      imageQuality: 85,
    );
    if (picked == null) return;

    setState(() => _isUploadingLogo = true);
    try {
      final bytes = await picked.readAsBytes();
      final url = await widget.storageService.uploadPhoto(
        bytes: bytes,
        trackingId: 'shop-logo',
      );
      await _docRef.set({'logoUrl': url}, SetOptions(merge: true));
      if (mounted) {
        setState(() {
          _logoUrl = url;
          _isUploadingLogo = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isUploadingLogo = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Upload failed: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return _SettingsPageCard(
      title: 'Shop / Business Info',
      subtitle: 'This is shown in customer notifications and receipts',
      icon: Icons.storefront_outlined,
      child: _isLoading
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            )
          : _loadError != null
              ? _SettingsErrorRetry(message: _loadError!, onRetry: _load)
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        GestureDetector(
                          onTap: _isUploadingLogo ? null : _pickAndUploadLogo,
                          child: Container(
                            width: 64,
                            height: 64,
                            decoration: BoxDecoration(
                              color: kAdminBg,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: kAdminCardBorder),
                            ),
                            clipBehavior: Clip.antiAlias,
                            child: _isUploadingLogo
                                ? const Center(
                                    child: SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: CircularProgressIndicator(
                                          strokeWidth: 2),
                                    ),
                                  )
                                : (_logoUrl != null && _logoUrl!.isNotEmpty)
                                    ? Image.network(_logoUrl!,
                                        fit: BoxFit.cover)
                                    : Icon(Icons.storefront_outlined,
                                        color: kAdminTextGray, size: 28),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _shopName.isEmpty ? 'No shop name' : _shopName,
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: _shopName.isEmpty
                                      ? kAdminTextGray
                                      : kAdminTextDark,
                                  fontStyle: _shopName.isEmpty
                                      ? FontStyle.italic
                                      : FontStyle.normal,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                'Tap the logo to change it',
                                style: const TextStyle(
                                    fontSize: 11, color: kAdminTextGray),
                              ),
                            ],
                          ),
                        ),
                        InkWell(
                          onTap: _editShopName,
                          borderRadius: BorderRadius.circular(20),
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: kAdminBrand.withValues(alpha: 0.08),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.edit_outlined,
                                size: 16, color: kAdminBrand),
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 28, color: kAdminCardBorder),
                    _SettingsInfoRow(
                      label: 'Address',
                      value: _address.isEmpty ? 'Not yet set' : _address,
                      isPlaceholder: _address.isEmpty,
                      onEdit: _editAddress,
                    ),
                    const Divider(height: 1, color: kAdminCardBorder),
                    _SettingsInfoRow(
                      label: 'Contact Number',
                      value: _contactNumber.isEmpty
                          ? 'Not yet set'
                          : _contactNumber,
                      isPlaceholder: _contactNumber.isEmpty,
                      onEdit: _editContactNumber,
                    ),
                    const Divider(height: 1, color: kAdminCardBorder),
                    _SettingsInfoRow(
                      label: 'Business Hours',
                      value: _businessHours.isEmpty
                          ? 'Not yet set'
                          : _businessHours,
                      isPlaceholder: _businessHours.isEmpty,
                      onEdit: _editBusinessHours,
                    ),
                  ],
                ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════
// 2. Account / Profile Settings — edit icons, no large button
// ══════════════════════════════════════════════════════════════════

class _AccountSettingsSection extends StatefulWidget {
  const _AccountSettingsSection();

  @override
  State<_AccountSettingsSection> createState() =>
      _AccountSettingsSectionState();
}

class _AccountSettingsSectionState extends State<_AccountSettingsSection> {
  String _name = '';
  String _email = '';
  String? _photoUrl;
  bool _isLoading = true;
  bool _isUploadingPhoto = false;
  String? _loadError;
  final _storageService = StorageService();

  DocumentReference? get _docRef {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return null;
    return FirebaseFirestore.instance.collection('admins').doc(uid);
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _loadError = null;
    });
    final ref = _docRef;
    if (ref == null) {
      setState(() => _isLoading = false);
      return;
    }
    try {
      final doc = await ref.get();
      if (!mounted) return;
      if (doc.exists) {
        final data = doc.data() as Map<String, dynamic>;
        setState(() {
          _name = data['name'] ?? '';
          _email =
              data['email'] ?? FirebaseAuth.instance.currentUser?.email ?? '';
          _photoUrl = data['profilePhotoUrl'] as String?;
          _isLoading = false;
        });
      } else {
        setState(() {
          _email = FirebaseAuth.instance.currentUser?.email ?? '';
          _isLoading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _loadError = 'Unable to load account info: $e';
      });
    }
  }

  Future<void> _editName() async {
    final result = await _showEditFieldDialog(
      context,
      title: 'Admin Name',
      initialValue: _name,
      hint: 'Your full name',
    );
    if (result == null || result == _name) return;

    final ref = _docRef;
    if (ref == null) return;
    try {
      await ref.set({'name': result}, SetOptions(merge: true));
      if (mounted) {
        setState(() => _name = result);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Pangalan na-update.'),
              backgroundColor: Color(0xFF16A34A)),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  Future<void> _pickAndUploadPhoto() async {
    final picked = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 600,
      imageQuality: 85,
    );
    if (picked == null) return;

    final ref = _docRef;
    if (ref == null) return;

    setState(() => _isUploadingPhoto = true);
    try {
      final bytes = await picked.readAsBytes();
      final url = await _storageService.uploadPhoto(
        bytes: bytes,
        trackingId: 'admin-profile-${FirebaseAuth.instance.currentUser?.uid}',
      );
      await ref.set({'profilePhotoUrl': url}, SetOptions(merge: true));
      if (mounted) {
        setState(() {
          _photoUrl = url;
          _isUploadingPhoto = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isUploadingPhoto = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Upload failed: $e')),
        );
      }
    }
  }

  Future<void> _requestPasswordReset() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: const Text('Change Password'),
        content: Text(
          'We\'ll send a password reset link to $_email. '
          'Follow the link to set a new password.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
                backgroundColor: kAdminBrand, foregroundColor: Colors.white),
            child: const Text('Send Reset Link'),
          ),
        ],
      ),
    );

    if (confirmed != true || _email.isEmpty) return;
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: _email);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Reset link sent to $_email.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return _SettingsPageCard(
      title: 'Account / Profile Settings',
      subtitle: 'Your admin name, email, and profile photo',
      icon: Icons.person_outline,
      child: _isLoading
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            )
          : _loadError != null
              ? _SettingsErrorRetry(message: _loadError!, onRetry: _load)
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        GestureDetector(
                          onTap:
                              _isUploadingPhoto ? null : _pickAndUploadPhoto,
                          child: Container(
                            width: 56,
                            height: 56,
                            decoration: BoxDecoration(
                              color: kAdminBg,
                              shape: BoxShape.circle,
                              border: Border.all(color: kAdminCardBorder),
                            ),
                            clipBehavior: Clip.antiAlias,
                            child: _isUploadingPhoto
                                ? const Center(
                                    child: SizedBox(
                                      width: 18,
                                      height: 18,
                                      child: CircularProgressIndicator(
                                          strokeWidth: 2),
                                    ),
                                  )
                                : (_photoUrl != null && _photoUrl!.isNotEmpty)
                                    ? Image.network(_photoUrl!,
                                        fit: BoxFit.cover)
                                    : Icon(Icons.person, color: kAdminTextGray),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Tap the photo to change it',
                            style: const TextStyle(
                                fontSize: 11, color: kAdminTextGray),
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 28, color: kAdminCardBorder),
                    _SettingsInfoRow(
                      label: 'Admin Name',
                      value: _name.isEmpty ? 'Not yet set' : _name,
                      isPlaceholder: _name.isEmpty,
                      onEdit: _editName,
                    ),
                    const Divider(height: 1, color: kAdminCardBorder),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Email Address',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    color: kAdminTextGray,
                                  ),
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  _email,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: kAdminTextDark,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Divider(height: 1, color: kAdminCardBorder),
                    _SettingsInfoRow(
                      label: 'Password',
                      value: '••••••••',
                      onEdit: _requestPasswordReset,
                    ),
                  ],
                ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════
// 3. Notification Settings — dropdown/accordion per status, with
//    pre-filled default SMS templates from sms_service.dart
// ══════════════════════════════════════════════════════════════════

const List<String> _kNotifiableStatuses = [
  'Accepted',
  'In Home',
  'In Shop',
  'In Process',
  'Waiting for Parts',
  'Completed',
  'Declined',
];

/// Default scripted messages — follows the same template used in
/// sms_service.dart _buildMessage(), to keep the SMS tone consistent
/// even before the admin customizes it. Placeholders:
/// {trackingId}, {applianceType}, {technician}, {note}. The
/// scheduledDate is not included here because it's dynamic and
/// depends on the actual time — it stays handled by SmsService at runtime.
const Map<String, String> _kDefaultSmsTemplates = {
  'Accepted':
      'RepairTrack: Your repair request (ID: {trackingId}) for your '
          '{applianceType} has been ACCEPTED. Technician {technician} will '
          'be assisting you.',
  'In Home':
      'RepairTrack: Technician {technician} will visit your home to '
          'repair your {applianceType}. Please be available at that time.',
  'In Shop':
      'RepairTrack: Your {applianceType} (ID: {trackingId}) has been '
          'brought to our shop for repair. Assigned to technician '
          '{technician}. We will notify you once it is ready for pickup.',
  'In Process':
      'RepairTrack: Your {applianceType} repair (ID: {trackingId}) is '
          'now IN PROCESS.',
  'Waiting for Parts':
      'RepairTrack: Your {applianceType} repair (ID: {trackingId}) is '
          'currently waiting for parts.',
  'Completed':
      'RepairTrack: Great news! Your {applianceType} repair '
          '(ID: {trackingId}) is now COMPLETE and ready for pickup. Thank '
          'you for trusting RepairTrack!',
  'Declined':
      'RepairTrack: We\'re sorry, your repair request (ID: {trackingId}) '
          'for your {applianceType} has been DECLINED.',
};

class _NotificationSettingsSection extends StatefulWidget {
  const _NotificationSettingsSection();

  @override
  State<_NotificationSettingsSection> createState() =>
      _NotificationSettingsSectionState();
}

class _NotificationSettingsSectionState
    extends State<_NotificationSettingsSection> {
  final Map<String, bool> _smsToggles = {
    for (final s in _kNotifiableStatuses) s: true,
  };
  final Map<String, String> _customTemplates = {};
  bool _emailEnabled = false;
  bool _isLoading = true;
  String? _loadError;
  String? _expandedStatus;

  DocumentReference get _settingsDocRef => FirebaseFirestore.instance
      .collection('notificationSettings')
      .doc('config');

  DocumentReference get _templatesDocRef =>
      FirebaseFirestore.instance.collection('smsTemplates').doc('config');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _loadError = null;
    });
    try {
      final settingsDoc = await _settingsDocRef.get();
      final templatesDoc = await _templatesDocRef.get();
      if (!mounted) return;

      if (settingsDoc.exists) {
        final data = settingsDoc.data() as Map<String, dynamic>;
        final smsMap = data['smsEnabledByStatus'] as Map<String, dynamic>?;
        if (smsMap != null) {
          for (final s in _kNotifiableStatuses) {
            _smsToggles[s] = smsMap[s] as bool? ?? true;
          }
        }
        _emailEnabled = data['emailEnabled'] as bool? ?? false;
      }

      if (templatesDoc.exists) {
        final data = templatesDoc.data() as Map<String, dynamic>;
        for (final s in _kNotifiableStatuses) {
          final custom = data[s] as String?;
          if (custom != null && custom.trim().isNotEmpty) {
            _customTemplates[s] = custom;
          }
        }
      }

      setState(() => _isLoading = false);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _loadError = 'Unable to load notification settings: $e';
      });
    }
  }

  Future<void> _toggleSms(String status, bool value) async {
    setState(() => _smsToggles[status] = value);
    try {
      await _settingsDocRef.set({
        'smsEnabledByStatus': _smsToggles,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  Future<void> _toggleEmail(bool value) async {
    setState(() => _emailEnabled = value);
    try {
      await _settingsDocRef.set({
        'emailEnabled': value,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  Future<void> _editTemplate(String status) async {
    final currentValue =
        _customTemplates[status] ?? _kDefaultSmsTemplates[status] ?? '';

    final controller = TextEditingController(text: currentValue);

    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text('SMS Template — $status'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Placeholders: {trackingId}, {applianceType}, {technician}, {note}',
              style: TextStyle(fontSize: 11, color: kAdminTextGray),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: controller,
              maxLines: 5,
              decoration: _settingsFieldDecoration(
                  hint: 'Custom message for this status'),
            ),
          ],
        ),
        actions: [
          if (_customTemplates.containsKey(status))
            TextButton(
              onPressed: () => Navigator.pop(context, '__reset_to_default__'),
              child: const Text('Reset to Default',
                  style: TextStyle(color: Color(0xFFDC2626))),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            style: ElevatedButton.styleFrom(
                backgroundColor: kAdminBrand, foregroundColor: Colors.white),
            child: const Text('Save'),
          ),
        ],
      ),
    );

    if (result == null) return;

    try {
      if (result == '__reset_to_default__') {
        await _templatesDocRef.set(
            {status: FieldValue.delete()}, SetOptions(merge: true));
        if (mounted) {
          setState(() => _customTemplates.remove(status));
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Reset "$status" to default.')),
          );
        }
      } else {
        await _templatesDocRef.set({status: result}, SetOptions(merge: true));
        if (mounted) {
          setState(() => _customTemplates[status] = result);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Template for "$status" saved.')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return _SettingsPageCard(
      title: 'Notification Settings',
      subtitle: 'SMS templates (Semaphore) and which events trigger sending',
      icon: Icons.notifications_outlined,
      child: _isLoading
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            )
          : _loadError != null
              ? _SettingsErrorRetry(message: _loadError!, onRetry: _load)
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'SMS per Status',
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: kAdminTextDark),
                    ),
                    const SizedBox(height: 4),
                    ..._kNotifiableStatuses.map((status) {
                      final isExpanded = _expandedStatus == status;
                      final isCustomized =
                          _customTemplates.containsKey(status);
                      final previewText = _customTemplates[status] ??
                          _kDefaultSmsTemplates[status] ??
                          '';

                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        decoration: BoxDecoration(
                          color: kAdminBg,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: kAdminCardBorder),
                        ),
                        child: Column(
                          children: [
                            InkWell(
                              borderRadius: BorderRadius.circular(10),
                              onTap: () => setState(() {
                                _expandedStatus =
                                    isExpanded ? null : status;
                              }),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 10),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Row(
                                        children: [
                                          Text(status,
                                              style: const TextStyle(
                                                  fontSize: 13,
                                                  fontWeight:
                                                      FontWeight.w600,
                                                  color: kAdminTextDark)),
                                          if (isCustomized) ...[
                                            const SizedBox(width: 6),
                                            Container(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 6,
                                                      vertical: 2),
                                              decoration: BoxDecoration(
                                                color: kAdminBrand.withValues(
                                                    alpha: 0.1),
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        8),
                                              ),
                                              child: const Text(
                                                'Custom',
                                                style: TextStyle(
                                                    fontSize: 9,
                                                    fontWeight:
                                                        FontWeight.w600,
                                                    color: kAdminBrand),
                                              ),
                                            ),
                                          ],
                                        ],
                                      ),
                                    ),
                                    Switch(
                                      value: _smsToggles[status] ?? true,
                                      activeColor: kAdminBrand,
                                      onChanged: (v) => _toggleSms(status, v),
                                    ),
                                    Icon(
                                      isExpanded
                                          ? Icons.keyboard_arrow_up_rounded
                                          : Icons.keyboard_arrow_down_rounded,
                                      color: kAdminTextGray,
                                      size: 20,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            if (isExpanded)
                              Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    12, 0, 12, 12),
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    const Divider(
                                        height: 1, color: kAdminCardBorder),
                                    const SizedBox(height: 10),
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: Text(
                                            previewText,
                                            style: const TextStyle(
                                              fontSize: 12,
                                              color: kAdminTextGray,
                                              height: 1.4,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        InkWell(
                                          onTap: () => _editTemplate(status),
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          child: Container(
                                            padding: const EdgeInsets.all(8),
                                            decoration: BoxDecoration(
                                              color: kAdminBrand.withValues(
                                                  alpha: 0.08),
                                              shape: BoxShape.circle,
                                            ),
                                            child: const Icon(
                                                Icons.edit_outlined,
                                                size: 16,
                                                color: kAdminBrand),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                      );
                    }),

                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: kAdminBg,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: kAdminCardBorder),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('Email Notifications',
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w600,
                                        color: kAdminTextDark)),
                                Text(
                                  'If you also have email notifications set up',
                                  style: const TextStyle(
                                      fontSize: 11, color: kAdminTextGray),
                                ),
                              ],
                            ),
                          ),
                          Switch(
                            value: _emailEnabled,
                            activeColor: kAdminBrand,
                            onChanged: _toggleEmail,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════
// 4. Data & Security
// ══════════════════════════════════════════════════════════════════

class _DataSecuritySection extends StatefulWidget {
  const _DataSecuritySection();

  @override
  State<_DataSecuritySection> createState() => _DataSecuritySectionState();
}

class _DataSecuritySectionState extends State<_DataSecuritySection> {
  bool _isExporting = false;

  Future<void> _exportRepairRequests() async {
    setState(() => _isExporting = true);
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('repairRequests')
          .orderBy('createdAt', descending: true)
          .get();

      final records = snapshot.docs.map((doc) {
        final data = Map<String, dynamic>.from(doc.data());
        data['docId'] = doc.id;
        data.updateAll((key, value) {
          if (value is Timestamp) return value.toDate().toIso8601String();
          if (value is List) {
            return value.map((e) {
              if (e is Map) {
                final copy = Map<String, dynamic>.from(e);
                copy.updateAll((k, v) =>
                    v is Timestamp ? v.toDate().toIso8601String() : v);
                return copy;
              }
              return e;
            }).toList();
          }
          return value;
        });
        return data;
      }).toList();

      final jsonStr = const JsonEncoder.withIndent('  ').convert(records);

      if (mounted) {
        setState(() => _isExporting = false);
        _showExportDialog(jsonStr, records.length);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isExporting = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Export failed: $e')),
        );
      }
    }
  }

  void _showExportDialog(String jsonStr, int count) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text('Export — $count repair record(s)'),
        content: SizedBox(
          width: 500,
          height: 400,
          child: SingleChildScrollView(
            child: SelectableText(
              jsonStr,
              style: const TextStyle(fontSize: 11, fontFamily: 'monospace'),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton.icon(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: jsonStr));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Copied to clipboard.')),
              );
            },
            icon: const Icon(Icons.copy, size: 16),
            label: const Text('Copy to Clipboard'),
            style: ElevatedButton.styleFrom(
                backgroundColor: kAdminBrand, foregroundColor: Colors.white),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return _SettingsPageCard(
      title: 'Data & Security',
      subtitle: 'Backup/export data of repair records',
      icon: Icons.security_outlined,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SettingsPageTile(
            icon: Icons.download_outlined,
            label: 'Export Repair Data',
            subtitle: 'Export all repair requests as JSON',
            trailing: _isExporting
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.chevron_right_rounded,
                    size: 18, color: kAdminTextGray),
            onTap: _isExporting ? null : _exportRepairRequests,
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════
// 5. App Info (footer only, simple)
// ══════════════════════════════════════════════════════════════════

class _AppInfoSettingsSection extends StatelessWidget {
  const _AppInfoSettingsSection();

  Future<void> _confirmSignOut(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: const Text('Sign Out'),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFDC2626),
              foregroundColor: Colors.white,
            ),
            child: const Text('Sign Out'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await AuthService().logout();
      if (context.mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const WelcomeScreen()),
          (route) => false,
        );
      }
    }
  }

  void _showInfoDialog(BuildContext context, String title, String body) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text(title),
        content: Text(body, style: const TextStyle(fontSize: 13)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return _SettingsPageCard(
      title: 'App Info',
      subtitle: 'Version, terms, at contact/support info',
      icon: Icons.info_outline,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _SettingsPageTile(
            icon: Icons.info_outline,
            label: 'App Version',
            subtitle: '1.0.0',
            trailing: SizedBox.shrink(),
            onTap: null,
          ),
          _SettingsPageTile(
            icon: Icons.description_outlined,
            label: 'Terms of Service',
            subtitle: 'Basic terms of use for RepairTrack',
            trailing: const Icon(Icons.chevron_right_rounded,
                size: 18, color: kAdminTextGray),
            onTap: () => _showInfoDialog(
              context,
              'Terms of Service',
              'RepairTrack is a capstone/pilot app for tracking '
                  'appliance repair requests. By using it, you agree '
                  'to use it responsibly and not for any unlawful '
                  'purposes.',
            ),
          ),
          _SettingsPageTile(
            icon: Icons.privacy_tip_outlined,
            label: 'Privacy Policy',
            subtitle: 'How your data is used',
            trailing: const Icon(Icons.chevron_right_rounded,
                size: 18, color: kAdminTextGray),
            onTap: () => _showInfoDialog(
              context,
              'Privacy Policy',
              'Customer details (name, address, contact number) are '
                  'used only for processing repair requests and are not '
                  'shared with third parties except the SMS provider for '
                  'notifications.',
            ),
          ),
          _SettingsPageTile(
            icon: Icons.support_agent_outlined,
            label: 'Contact / Support',
            subtitle: 'For help with the app',
            trailing: const Icon(Icons.chevron_right_rounded,
                size: 18, color: kAdminTextGray),
            onTap: () => _showInfoDialog(
              context,
              'Contact / Support',
              'For issues or questions about the RepairTrack app, '
                  'please contact the developer/admin of this system.',
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => _confirmSignOut(context),
              icon:
                  const Icon(Icons.logout, size: 18, color: Color(0xFFDC2626)),
              label: const Text('Sign Out',
                  style: TextStyle(color: Color(0xFFDC2626))),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 13),
                side: const BorderSide(color: Color(0xFFFECACA)),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Shared row tile ──────────────────────────────────────────────
class _SettingsPageTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final Widget trailing;
  final VoidCallback? onTap;

  const _SettingsPageTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.trailing,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(
          children: [
            Icon(icon, size: 20, color: kAdminBrand),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: kAdminTextDark),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(fontSize: 11, color: kAdminTextGray),
                  ),
                ],
              ),
            ),
            trailing,
          ],
        ),
      ),
    );
  }
}

/// Reusable error + retry widget for sections that fail to
/// load (e.g. Firestore rules issue, no internet, etc.) — so
/// there's no "silent hang"; the admin immediately sees an
/// error message and a retry button.
class _SettingsErrorRetry extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const _SettingsErrorRetry({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.error_outline_rounded,
                color: Color(0xFFDC2626), size: 18),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(fontSize: 12, color: Color(0xFF991B1B)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: onRetry,
          icon: const Icon(Icons.refresh_rounded, size: 16),
          label: const Text('Retry'),
          style: OutlinedButton.styleFrom(
            foregroundColor: kAdminBrand,
            side: const BorderSide(color: kAdminCardBorder),
          ),
        ),
      ],
    );
  }
}
