
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// Default [FirebaseOptions] for use with your Firebase apps.

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyBMfsIiwIELOzpMKpXJQbnYVl3fmQpR4MA',
    appId: '1:205516311125:web:4bda888b5814904a0be2dc',
    messagingSenderId: '205516311125',
    projectId: 'repair-tracker-app-e9ace',
    authDomain: 'repair-tracker-app-e9ace.firebaseapp.com',
    storageBucket: 'repair-tracker-app-e9ace.firebasestorage.app',
    measurementId: 'G-EP71HTZ3NR',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyCR66fYHEVx5Fq1pH4ceIJT81kZ3ZsQZeg',
    appId: '1:205516311125:android:330d038fb5876a420be2dc',
    messagingSenderId: '205516311125',
    projectId: 'repair-tracker-app-e9ace',
    storageBucket: 'repair-tracker-app-e9ace.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyAfXKc7YfaDrja9Xve0wDvgMDI7F6naEgU',
    appId: '1:205516311125:ios:f9f1d76e44ba4dc00be2dc',
    messagingSenderId: '205516311125',
    projectId: 'repair-tracker-app-e9ace',
    storageBucket: 'repair-tracker-app-e9ace.firebasestorage.app',
    iosBundleId: 'com.example.flutterApplication1',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyAfXKc7YfaDrja9Xve0wDvgMDI7F6naEgU',
    appId: '1:205516311125:ios:f9f1d76e44ba4dc00be2dc',
    messagingSenderId: '205516311125',
    projectId: 'repair-tracker-app-e9ace',
    storageBucket: 'repair-tracker-app-e9ace.firebasestorage.app',
    iosBundleId: 'com.example.flutterApplication1',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyBMfsIiwIELOzpMKpXJQbnYVl3fmQpR4MA',
    appId: '1:205516311125:web:b57c05d03ce0f8b90be2dc',
    messagingSenderId: '205516311125',
    projectId: 'repair-tracker-app-e9ace',
    authDomain: 'repair-tracker-app-e9ace.firebaseapp.com',
    storageBucket: 'repair-tracker-app-e9ace.firebasestorage.app',
    measurementId: 'G-K3ZRF5HMP3',
  );

}